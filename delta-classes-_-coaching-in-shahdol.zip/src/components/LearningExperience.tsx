import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles, Check, BookOpen, Compass, Layers, Target } from 'lucide-react';

export const LearningExperience: React.FC = () => {
  const [activeCycleIndex, setActiveCycleIndex] = useState(0);

  const cycleSteps = [
    {
      id: 'step-1',
      number: '01',
      title: 'Understand',
      subtitle: 'First-Principles Mathematical Logic',
      description: 'Before touching calculation shortcuts, students learn the origin, geometry, and underlying mechanics of the formula. Why does it work? Where did it come from?',
      keyActivity: 'Classroom Concept Breakdown',
      sampleFormula: 'f(x) = ax² + bx + c ⟹ Completing the square derivation',
      deliverable: 'Concept Notebook & Visual Graph Models',
    },
    {
      id: 'step-2',
      number: '02',
      title: 'Practise',
      subtitle: 'Graded Daily Problem Sets',
      description: 'Moving from fundamental level-1 textbook problems to multi-step problem statements. Students build calculation endurance, arithmetic speed, and sign accuracy.',
      keyActivity: 'Structured Problem Progression (Level 1 ➔ 2 ➔ 3)',
      sampleFormula: 'x = [-b ± √(b² - 4ac)] / 2a ⟹ Discriminant Δ analysis',
      deliverable: 'Daily Practice Sheet & Error Margin Tracker',
    },
    {
      id: 'step-3',
      number: '03',
      title: 'Review',
      subtitle: 'Roadblock Diagnosis & Doubt Resolution',
      description: 'Pinpointing the exact point of error—was it an algebraic slip, misread question, or conceptual gap? Doubts are dissected patiently until 100% clear.',
      keyActivity: 'Dedicated One-on-One Question Clarification',
      sampleFormula: 'Δ > 0 (Distinct Real) | Δ = 0 (Equal) | Δ < 0 (Complex)',
      deliverable: 'Mistake Journal & Correction Notes',
    },
    {
      id: 'step-4',
      number: '04',
      title: 'Improve',
      subtitle: 'Exam Stamina & Timed Execution',
      description: 'Synthesizing individual chapters into full-length test simulations. Students cultivate calm problem selection, time budgeting, and neat answer presentation.',
      keyActivity: 'Periodic Timed Mock Assessments',
      sampleFormula: 'Speed + Precision = Exam Confidence',
      deliverable: 'Graded Assessment Report & Progress Milestone',
    },
  ];

  const currentStep = cycleSteps[activeCycleIndex];

  return (
    <section id="experience" aria-label="Learning Experience" className="py-20 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 text-xs font-mono text-[#6546E8] uppercase tracking-wider mb-2 font-semibold">
            <Sparkles className="w-4 h-4" />
            <span>Proposed Academic Workflow</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-normal text-[#151A3B] tracking-tight" style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}>
            The 4-Stage Learning Cycle
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#667085] leading-relaxed">
            A structured progression that bridges classroom theory into autonomous student confidence. Presented as a suggested operational model for Delta Classes.
          </p>
        </div>

        {/* 4-Stage Progress Stepper */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 mb-8">
          {cycleSteps.map((step, idx) => (
            <button
              key={step.id}
              type="button"
              onClick={() => setActiveCycleIndex(idx)}
              className={`p-5 rounded-2xl text-left transition-all border cursor-pointer ${
                activeCycleIndex === idx
                  ? 'bg-white border-[#6546E8] shadow-sm text-[#151A3B]'
                  : 'bg-[#F8F9FF] border-slate-200/60 text-[#667085] hover:text-[#151A3B] hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs font-mono font-bold ${activeCycleIndex === idx ? 'text-[#6546E8]' : 'text-slate-400'}`}>
                  {step.number}
                </span>
                {idx < 3 && <ArrowRight className="w-3.5 h-3.5 text-slate-300 hidden md:block" />}
              </div>
              <div className="text-base font-bold text-[#151A3B] mb-0.5">{step.title}</div>
              <div className="text-xs text-[#667085] truncate">{step.subtitle}</div>
            </button>
          ))}
        </div>

        {/* Split Layout Showcase */}
        <div className="rounded-2xl bg-[#F8F9FF] border border-slate-200/80 p-7 sm:p-9 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-xs">
          
          {/* Left Details (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-[#6546E8] font-semibold uppercase tracking-wider bg-[#ECE8FD] px-3 py-1 rounded-md">
              <span>STAGE {currentStep.number}</span>
              <span className="text-slate-400">·</span>
              <span>{currentStep.title.toUpperCase()}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-bold text-[#151A3B]">
              {currentStep.subtitle}
            </h3>

            <p className="text-sm text-[#667085] leading-relaxed">
              {currentStep.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-200/60">
              <div className="p-3.5 rounded-xl bg-white border border-slate-200/70">
                <span className="block text-[11px] text-[#667085] font-mono">PRIMARY ACTIVITY</span>
                <span className="text-xs sm:text-sm font-bold text-[#151A3B] mt-1 block">{currentStep.keyActivity}</span>
              </div>
              <div className="p-3.5 rounded-xl bg-white border border-slate-200/70">
                <span className="block text-[11px] text-[#667085] font-mono">STUDENT TAKEAWAY</span>
                <span className="text-xs sm:text-sm font-bold text-[#151A3B] mt-1 block">{currentStep.deliverable}</span>
              </div>
            </div>
          </div>

          {/* Right Visual Box (5 cols) */}
          <div className="lg:col-span-5 bg-white border border-slate-200/80 rounded-2xl p-6 font-mono text-xs text-[#151A3B] shadow-xs">
            <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 text-[11px] text-[#667085]">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-200" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-200" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-200" />
              </div>
              <span>PROBLEM_LOGIC.ts</span>
            </div>

            <div className="pt-4 space-y-3 text-xs leading-relaxed font-sans">
              <p className="text-[#6546E8] font-mono text-[11px] font-semibold">// Step-by-Step Logic Application</p>
              <div className="p-3 rounded-xl bg-[#F8F9FF] border border-slate-200/70 font-mono text-xs text-[#151A3B]">
                {currentStep.sampleFormula}
              </div>
              <p className="text-[#667085] text-xs">
                Disciplined step formatting helps students catch calculation traps before they affect the final answer.
              </p>
              <div className="flex items-center gap-2 text-emerald-700 text-xs pt-1 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verified Conceptual Consistency</span>
              </div>
            </div>
          </div>

        </div>

        {/* Clean Grid of Benefits */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-slate-100">
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] shrink-0 mt-0.5">
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-[#151A3B]">No Memorization Traps</h4>
              <p className="text-xs text-[#667085] mt-1">Students learn how theorems are derived before memorizing formulas.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] shrink-0 mt-0.5">
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-[#151A3B]">Daily Error Analysis</h4>
              <p className="text-xs text-[#667085] mt-1">Homework reviews identify individual student slip patterns early.</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] shrink-0 mt-0.5">
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-[#151A3B]">Exam Calmness</h4>
              <p className="text-xs text-[#667085] mt-1">Timed practice replicates test pressure so students stay calm on exam day.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
