import React, { useState, useEffect } from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { X, Send, MessageSquare, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProgram?: string;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({ 
  isOpen, 
  onClose, 
  selectedProgram = '' 
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    gradeLevel: 'Class 10',
    program: selectedProgram || 'Mathematics Coaching',
    preferredCallback: 'Anytime during day',
    queryNotes: '',
    consent: true,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedWhatsAppUrl, setSubmittedWhatsAppUrl] = useState('');

  useEffect(() => {
    if (selectedProgram) {
      setFormData((prev) => ({ ...prev, program: selectedProgram }));
    }
  }, [selectedProgram]);

  if (!isOpen) return null;

  const classOptions = [
    'Class 9',
    'Class 10',
    'Class 11 (Maths)',
    'Class 12 (Maths)',
    'Competitive Baseline / Foundation',
    'Other / Not sure',
  ];

  const callbackOptions = [
    'Anytime during day',
    'Morning (9:00 AM – 12:00 PM)',
    'Afternoon (1:00 PM – 4:00 PM)',
    'Evening (4:00 PM – 8:00 PM)',
  ];

  const programOptions = [
    'Mathematics Coaching',
    'Concept Building and Practice',
    'Academic Support / Exam Preparation',
    'General Enquiry / Batch Timings',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.fullName.trim()) {
      errs.fullName = 'Please enter student or parent name';
    } else if (formData.fullName.trim().length < 2) {
      errs.fullName = 'Name should be at least 2 characters';
    }

    const cleanPhone = formData.phone.replace(/[^0-9]/g, '');
    if (!cleanPhone) {
      errs.phone = 'Please enter a 10-digit mobile number';
    } else if (cleanPhone.length < 10) {
      errs.phone = 'Please enter a valid 10-digit mobile number';
    }

    if (!formData.consent) {
      errs.consent = 'Please confirm consent to be contacted regarding this enquiry';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const waText = [
      `Namaste Delta Classes,`,
      `I would like to enquire about coaching for ${formData.fullName}.`,
      `• Class/Level: ${formData.gradeLevel}`,
      `• Program: ${formData.program}`,
      `• Contact Phone: ${formData.phone}`,
      formData.preferredCallback ? `• Preferred Callback Time: ${formData.preferredCallback}` : '',
      formData.queryNotes.trim() ? `• Question / Note: ${formData.queryNotes.trim()}` : '',
      `Please share available batches, timings, and admission details.`,
    ]
      .filter(Boolean)
      .join('\n');

    const cleanInstitutePhone = INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '');
    const waUrl = `https://wa.me/${cleanInstitutePhone}?text=${encodeURIComponent(waText)}`;
    
    setSubmittedWhatsAppUrl(waUrl);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFormData({
      fullName: '',
      phone: '',
      gradeLevel: 'Class 10',
      program: 'Mathematics Coaching',
      preferredCallback: 'Anytime during day',
      queryNotes: '',
      consent: true,
    });
    setErrors({});
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div className="bg-white border border-slate-100 max-w-lg w-full rounded-3xl p-6 sm:p-8 shadow-2xl text-[#151A3B] relative max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-[#151A3B] p-2 rounded-full bg-[#F8F9FF] transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <div>
              <span className="text-[11px] font-bold tracking-[0.15em] text-[#4338CA] uppercase block mb-1">
                ADMISSION & BATCH INQUIRY
              </span>
              <h3 
                className="text-2xl font-normal text-[#151A3B]"
                style={{ fontFamily: 'var(--font-serif)' }}
              >
                Connect with Delta Classes
              </h3>
              <p className="text-xs text-[#667085] mt-1">
                Fill in your details below. You can also send this enquiry directly via WhatsApp.
              </p>
            </div>

            {/* Name */}
            <div>
              <label htmlFor="modal-name" className="block text-xs font-semibold text-[#151A3B] mb-1">
                Student / Parent Name <span className="text-[#4338CA]">*</span>
              </label>
              <input
                id="modal-name"
                type="text"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="e.g. Rahul Sharma"
                className={`w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-[#F8FAFF] border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
                  errors.fullName ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200/90 focus:border-[#4338CA] focus:ring-[#EEF2FF]'
                }`}
              />
              {errors.fullName && (
                <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.fullName}</span>
                </p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="modal-phone" className="block text-xs font-semibold text-[#151A3B] mb-1">
                Mobile Number <span className="text-[#4338CA]">*</span>
              </label>
              <input
                id="modal-phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="10-digit mobile number"
                className={`w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-[#F8FAFF] border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
                  errors.phone ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200/90 focus:border-[#4338CA] focus:ring-[#EEF2FF]'
                }`}
              />
              {errors.phone && (
                <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.phone}</span>
                </p>
              )}
            </div>

            {/* Grade & Program */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label htmlFor="modal-grade" className="block text-xs font-semibold text-[#151A3B] mb-1">
                  Class / Level
                </label>
                <select
                  id="modal-grade"
                  value={formData.gradeLevel}
                  onChange={(e) => setFormData({ ...formData, gradeLevel: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-[#F8FAFF] border border-slate-200/90 rounded-xl focus:outline-none focus:border-[#4338CA]"
                >
                  {classOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="modal-program" className="block text-xs font-semibold text-[#151A3B] mb-1">
                  Program
                </label>
                <select
                  id="modal-program"
                  value={formData.program}
                  onChange={(e) => setFormData({ ...formData, program: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-[#F8FAFF] border border-slate-200/90 rounded-xl focus:outline-none focus:border-[#4338CA]"
                >
                  {programOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Callback time */}
            <div>
              <label htmlFor="modal-callback" className="block text-xs font-semibold text-[#151A3B] mb-1">
                Preferred Callback Time
              </label>
              <select
                id="modal-callback"
                value={formData.preferredCallback}
                onChange={(e) => setFormData({ ...formData, preferredCallback: e.target.value })}
                className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-[#F8FAFF] border border-slate-200/90 rounded-xl focus:outline-none focus:border-[#4338CA]"
              >
                {callbackOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            {/* Questions/Notes */}
            <div>
              <label htmlFor="modal-notes" className="block text-xs font-semibold text-[#151A3B] mb-1">
                Specific Question / Notes <span className="text-[#667085] font-normal">(Optional)</span>
              </label>
              <textarea
                id="modal-notes"
                rows={2}
                value={formData.queryNotes}
                onChange={(e) => setFormData({ ...formData, queryNotes: e.target.value })}
                placeholder="e.g. Inquiring about Class 10 board prep batch timing..."
                className="w-full px-3.5 py-2 text-xs text-[#151A3B] bg-[#F8FAFF] border border-slate-200/90 rounded-xl focus:outline-none focus:border-[#4338CA]"
              />
            </div>

            {/* Consent */}
            <div>
              <label className="flex items-start gap-2.5 text-xs text-[#667085] cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.consent}
                  onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-[#4338CA] focus:ring-[#4338CA]"
                />
                <span>
                  I consent to receive contact from Delta Classes regarding this coaching enquiry.
                </span>
              </label>
              {errors.consent && (
                <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.consent}</span>
                </p>
              )}
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-[13px] font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] active:bg-[#312E81] rounded-full transition-colors shadow-sm cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Submit & Open WhatsApp</span>
              </button>
            </div>
          </form>
        ) : (
          /* Confirmation State */
          <div className="py-6 px-2 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div>
              <h3 
                className="text-2xl font-normal text-[#151A3B]"
                style={{ fontFamily: 'var(--font-serif)' }}
              >
                Enquiry Validated Successfully!
              </h3>
              <p className="text-xs text-[#667085] mt-1">
                Thank you, <strong className="text-[#4338CA] font-bold">{formData.fullName}</strong>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#F8FAFF] border border-slate-200/80 text-xs text-[#667085] text-left space-y-2">
              <div className="flex items-center gap-1.5 text-[#4338CA] font-semibold">
                <Sparkles className="w-4 h-4" />
                <span>Demo Mode Confirmation</span>
              </div>
              <p>
                Because this is an interactive demo without a remote production database, this submission has not been stored on any server.
              </p>
              <p>
                To send this enquiry directly to Delta Classes right now, tap the button below to open WhatsApp with all your details pre-filled!
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <a
                href={submittedWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-[13px] font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-full transition-colors shadow-sm"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Continue on WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-3 text-xs font-semibold text-[#151A3B] bg-slate-100 hover:bg-slate-200 rounded-full transition-colors cursor-pointer"
              >
                Submit Another
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
