import React from 'react';

interface DeltaLogoProps {
  className?: string;
  showTagline?: boolean;
}

export const DeltaLogo: React.FC<DeltaLogoProps> = ({ className = '', showTagline = true }) => {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Precision Delta Mark Vector from reference image */}
      <svg
        width="38"
        height="38"
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
        aria-hidden="true"
      >
        <path
          d="M20 4L4 34H12.5L20 19L27.5 34H36L20 4Z"
          fill="url(#delta_grad_main)"
        />
        <path
          d="M20 19L15 29H25L20 19Z"
          fill="url(#delta_grad_inner)"
          opacity="0.9"
        />
        <defs>
          <linearGradient id="delta_grad_main" x1="4" y1="4" x2="36" y2="34" gradientUnits="userSpaceOnUse">
            <stop stopColor="#3B82F6" />
            <stop offset="0.6" stopColor="#4F46E5" />
            <stop offset="1" stopColor="#3730A3" />
          </linearGradient>
          <linearGradient id="delta_grad_inner" x1="15" y1="19" x2="25" y2="29" gradientUnits="userSpaceOnUse">
            <stop stopColor="#6366F1" />
            <stop offset="1" stopColor="#4338CA" />
          </linearGradient>
        </defs>
      </svg>

      {/* Brand Wordmark & Tagline */}
      <div className="flex flex-col">
        <span className="font-extrabold text-[15px] sm:text-[17px] tracking-[0.06em] text-[#151A3B] leading-none uppercase">
          DELTA CLASSES
        </span>
        {showTagline && (
          <span className="text-[10px] text-[#667085] tracking-widest mt-1 font-medium">
            Learn <span className="text-slate-300">·</span> Practice <span className="text-slate-300">·</span> Grow
          </span>
        )}
      </div>
    </div>
  );
};
