import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Phone, MessageSquare } from 'lucide-react';

interface ContactBandProps {
  onEnquireClick?: () => void;
}

export const ContactBand: React.FC<ContactBandProps> = () => {
  return (
    <section aria-label="Contact Action Band" className="bg-[#EEF2FF] border-y border-slate-100/90 py-14 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-10">
          
          {/* Left: Origami Paper Plane + Heading + Supporting Copy */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-5 max-w-2xl">
            {/* Paper plane icon from reference */}
            <div className="shrink-0 pt-1 select-none">
              <img
                src="/assets/paper_plane.png"
                alt="Origami paper plane"
                className="w-14 h-auto"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-2">
              <h2 
                className="text-2xl sm:text-3xl lg:text-[32px] font-normal text-[#151A3B] leading-tight"
                style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
              >
                Take the First Step<br className="hidden sm:inline" /> Towards Your Goals
              </h2>
              <p className="text-xs sm:text-[13px] text-[#667085] leading-relaxed">
                Get in touch with us for class details, course information and admission enquiries.
              </p>
            </div>
          </div>

          {/* Right: Looping Doodle + Pill CTAs + Public Contact Number */}
          <div className="flex flex-col sm:flex-row items-center gap-6 shrink-0">
            {/* Looping decorative doodle arrow from reference */}
            <svg
              width="60"
              height="30"
              viewBox="0 0 60 30"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="hidden xl:block text-[#4338CA]/60"
              aria-hidden="true"
            >
              <path
                d="M4 18C16 4 30 2 24 16C19 28 42 26 56 14"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>

            <div className="flex flex-col items-center sm:items-end gap-2.5">
              <div className="flex flex-wrap items-center justify-center gap-3">
                {/* Chat on WhatsApp Pill Button */}
                <a
                  href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                    INSTITUTE_CONFIG.whatsappMessageTemplate
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-[13px] font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] active:bg-[#312E81] rounded-full shadow-sm transition-all whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
                >
                  <MessageSquare className="w-4 h-4 fill-white" />
                  <span>Chat on WhatsApp</span>
                </a>

                {/* Call Now Pill Button */}
                <a
                  href={`tel:${INSTITUTE_CONFIG.phone}`}
                  className="inline-flex items-center gap-2 px-6 py-3 text-xs sm:text-[13px] font-semibold text-[#4338CA] hover:text-[#3730A3] bg-white/90 hover:bg-white border border-[#4338CA]/30 rounded-full transition-all whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
                >
                  <Phone className="w-3.5 h-3.5 text-[#4338CA]" />
                  <span>Call Now</span>
                </a>
              </div>

              {/* Listed Phone Number & Label */}
              <div className="text-center sm:text-right pt-0.5">
                <span className="text-xs sm:text-[13px] font-bold text-[#151A3B] font-mono tabular-nums block">
                  {INSTITUTE_CONFIG.phoneDisplay}
                </span>
                <span className="text-[11px] text-[#667085] block">
                  (Public listing number)
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
