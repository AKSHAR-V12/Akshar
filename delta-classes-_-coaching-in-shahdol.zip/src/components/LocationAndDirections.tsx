import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { MapPin, Navigation, Clock, ExternalLink } from 'lucide-react';

export const LocationAndDirections: React.FC = () => {
  return (
    <section id="location" aria-label="Location & Directions" className="py-20 bg-[#F8FAFF] border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-[#4338CA] uppercase tracking-wider mb-2 font-semibold bg-[#EEF2FF] px-3 py-1 rounded-full">
            <MapPin className="w-3.5 h-3.5" />
            <span>Institute Location</span>
          </div>
          <h2 
            className="text-3xl sm:text-4xl font-normal text-[#151A3B] tracking-tight"
            style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
          >
            Find Delta Classes in Shahdol
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-[#667085] leading-relaxed">
            Conveniently located in Bhatnagar near Jhula Pul and Gayatri Mandir. Use the Google Maps navigation link below for directions.
          </p>
        </div>

        {/* Location Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Address & Landmark Info (6 cols) */}
          <div className="lg:col-span-6 flex flex-col justify-between p-7 sm:p-8 rounded-2xl bg-white border border-slate-100 space-y-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#4338CA] uppercase tracking-wider">
                <Navigation className="w-4 h-4" />
                <span>Researched Public Address</span>
              </div>

              <div className="space-y-1">
                <h3 className="text-xl font-bold text-[#151A3B]">
                  {INSTITUTE_CONFIG.businessName}
                </h3>
                <p className="text-sm text-[#667085] leading-relaxed">
                  {INSTITUTE_CONFIG.addressFull}
                </p>
              </div>

              {/* Landmark Callout */}
              <div className="p-4 rounded-xl bg-[#F8FAFF] border border-slate-100 space-y-1">
                <span className="text-[11px] font-mono text-[#4338CA] font-semibold uppercase tracking-wider block">
                  Prominent Landmark
                </span>
                <p className="text-xs sm:text-sm text-[#151A3B]">
                  {INSTITUTE_CONFIG.landmark}
                </p>
                <p className="text-[11px] text-[#667085] pt-0.5">
                  Convenient for students traveling from nearby schools and residential sectors across Shahdol.
                </p>
              </div>

              {/* Research Disclaimer */}
              <p className="text-[11px] text-[#667085] leading-normal">
                * Note: Address reflects public directory listings as of research date. Please verify current office hours before traveling.
              </p>
            </div>

            {/* Google Maps External Directions Action */}
            <div className="pt-4 border-t border-slate-100">
              <a
                href={INSTITUTE_CONFIG.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-[13px] font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] active:bg-[#312E81] rounded-full transition-colors shadow-sm"
              >
                <Navigation className="w-4 h-4" />
                <span>Open in Google Maps for Directions</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>
            </div>
          </div>

          {/* Contact Details & Visiting Hours Card (6 cols) */}
          <div className="lg:col-span-6 flex flex-col justify-between p-7 sm:p-8 rounded-2xl bg-white border border-slate-100 space-y-6 shadow-sm">
            <div className="space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#4338CA] uppercase tracking-wider">
                <Clock className="w-4 h-4" />
                <span>Contact & Visiting Information</span>
              </div>

              {/* Listed Phone */}
              <div className="p-4 rounded-xl bg-[#F8FAFF] border border-slate-100">
                <span className="text-[11px] font-mono text-[#667085] uppercase tracking-wider block">
                  Telephone Contact
                </span>
                <a
                  href={`tel:${INSTITUTE_CONFIG.phone}`}
                  className="text-base sm:text-lg font-bold text-[#151A3B] hover:text-[#4338CA] font-mono tabular-nums transition-colors inline-block mt-0.5"
                >
                  {INSTITUTE_CONFIG.phoneDisplay}
                </a>
                <span className="block text-[11px] text-[#667085] mt-1">
                  Publicly listed institute contact number
                </span>
              </div>

              {/* Operating Hours Placeholder */}
              <div className="p-4 rounded-xl bg-[#F8FAFF] border border-slate-100">
                <span className="text-[11px] font-mono text-[#667085] uppercase tracking-wider block">
                  Class & Visiting Timings
                </span>
                <p className="text-xs sm:text-sm text-[#151A3B] mt-1">
                  {INSTITUTE_CONFIG.operatingHours || 'Batch schedules and visiting timings vary by class level and academic term.'}
                </p>
                <p className="text-[11px] text-[#667085] mt-1">
                  Please call or send a WhatsApp message prior to visiting to confirm current faculty availability.
                </p>
              </div>
            </div>

            {/* Quick Location Meta */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-[#667085]">
              <span>District: Shahdol (MP)</span>
              <span>PIN: {INSTITUTE_CONFIG.pincode}</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
