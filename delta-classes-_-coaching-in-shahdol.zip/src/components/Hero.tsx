import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { ArrowRight, Star, MapPin } from 'lucide-react';

interface HeroProps {
  onEnquireClick: () => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onEnquireClick, onExploreClick }) => {
  return (
    <section 
      id="home" 
      aria-label="Delta Classes Overview"
      className="relative overflow-hidden pt-10 pb-16 lg:pt-16 lg:pb-22 bg-white"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Two-column layout matching reference image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Copy & Actions (7 cols) */}
          <div className="lg:col-span-7 space-y-6 lg:pr-4">
            
            {/* Location Tag */}
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#4338CA]">
              <MapPin className="w-3.5 h-3.5 text-[#4338CA]" />
              <span>{INSTITUTE_CONFIG.locationCity}, {INSTITUTE_CONFIG.locationState}</span>
            </div>

            {/* Serif Headline with Purple 'Confidence.' */}
            <h1 
              className="text-4xl sm:text-5xl lg:text-[56px] font-normal text-[#151A3B] tracking-tight leading-[1.12]" 
              style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
            >
              Build Strong Concepts.<br className="hidden sm:inline" />
              Move Forward with <br className="hidden sm:inline" />
              <span className="text-[#4338CA]">Confidence.</span>
            </h1>

            {/* Concise Supporting Copy */}
            <p className="text-[15px] sm:text-base text-[#667085] leading-relaxed max-w-xl font-normal">
              Explore a focused learning environment designed to help students strengthen their understanding, practise consistently, and approach academic challenges with confidence.
            </p>

            {/* Two Pill Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                type="button"
                onClick={onEnquireClick}
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 text-xs sm:text-[13px] font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] active:bg-[#312E81] rounded-full shadow-sm transition-all cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
              >
                <span>Enquire About Classes</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onExploreClick}
                className="inline-flex items-center justify-center px-7 py-3.5 text-xs sm:text-[13px] font-semibold text-[#4338CA] hover:text-[#3730A3] bg-white hover:bg-[#F8F9FF] border border-[#4338CA]/30 rounded-full transition-all cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
              >
                Explore Learning
              </button>
            </div>

            {/* Public Listing Rating Line */}
            {INSTITUTE_CONFIG.showPublicRating && (
              <div className="pt-2 flex items-center gap-1.5 text-xs text-[#667085]">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                <p>
                  <strong className="text-[#151A3B] font-semibold">Public listing rating: 5.0/5 · 32 reviews</strong>{' '}
                  <span className="text-[#667085]">(as found during research; verify before launch).</span>
                </p>
              </div>
            )}

          </div>

          {/* Right Column: Hero Visual from Reference (5 cols) */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative max-w-[440px] w-full">
              {/* Image composition matching reference */}
              <div className="relative overflow-hidden rounded-3xl select-none">
                <img
                  src="/assets/hero_composition.png"
                  alt="Student solving mathematics equations on whiteboard at Delta Classes"
                  className="w-full h-auto object-cover rounded-3xl"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />

                {/* Interactive Clickable Overlay on Floating Badge */}
                <button
                  type="button"
                  onClick={onExploreClick}
                  aria-label="Explore learning programs - Better Concepts, Brighter Future"
                  className="absolute bottom-4 right-4 sm:bottom-6 sm:right-6 bg-white/95 hover:bg-white border border-slate-100 rounded-2xl px-5 py-3 shadow-lg flex items-center gap-4 text-left transition-transform hover:scale-[1.02] cursor-pointer"
                >
                  <div className="flex flex-col">
                    <span className="text-xs sm:text-[13px] font-bold text-[#151A3B]" style={{ fontFamily: 'var(--font-serif)' }}>
                      Better Concepts
                    </span>
                    <span className="text-xs sm:text-[13px] font-bold text-[#151A3B]" style={{ fontFamily: 'var(--font-serif)' }}>
                      Brighter Future
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#4338CA] shrink-0" />
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
