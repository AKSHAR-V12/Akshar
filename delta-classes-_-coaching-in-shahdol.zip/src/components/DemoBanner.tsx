import React, { useState } from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Sparkles, ChevronRight, X, MessageSquare } from 'lucide-react';

export const DemoBanner: React.FC = () => {
  const [isDismissed, setIsDismissed] = useState(false);
  const [showPitchModal, setShowPitchModal] = useState(false);

  if (isDismissed) return null;

  return (
    <>
      <aside aria-label="Demo notice" className="bg-[#F4F1FD] border-b border-[#ECE8FD] text-[#667085] text-xs py-2 px-4 relative z-40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#6546E8] uppercase tracking-wider text-[10px] bg-white px-2 py-0.5 rounded border border-[#ECE8FD]">
              Demo Concept
            </span>
            <p className="text-[#151A3B] text-[11px] sm:text-xs">
              Proposed sales website concept for <strong className="text-[#151A3B] font-bold">{INSTITUTE_CONFIG.businessName}</strong> (Shahdol, MP) · Prepared by <span className="text-[#6546E8] font-bold">{INSTITUTE_CONFIG.demoMode.preparedBy}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowPitchModal(true)}
              className="text-[11px] text-[#6546E8] hover:text-[#4930C9] underline underline-offset-2 flex items-center gap-1 cursor-pointer font-semibold"
            >
              <span>Why Delta Classes needs this</span>
              <ChevronRight className="w-3 h-3" />
            </button>
            <button
              type="button"
              onClick={() => setIsDismissed(true)}
              className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
              aria-label="Dismiss notice"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Owner Pitch Highlights Modal */}
      {showPitchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 max-w-xl w-full rounded-2xl p-6 sm:p-7 shadow-2xl text-[#151A3B] relative">
            <button
              type="button"
              onClick={() => setShowPitchModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-[#151A3B] p-1.5 rounded-lg bg-[#F8F9FF]"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-[#6546E8] text-xs font-mono uppercase tracking-wider mb-2 font-semibold">
              <Sparkles className="w-4 h-4" />
              <span>Commercial Value Proposal</span>
            </div>

            <h3 className="text-2xl font-bold text-[#151A3B] mb-1.5">
              Website Concept for {INSTITUTE_CONFIG.businessName}
            </h3>

            <p className="text-xs text-[#667085] mb-5">
              Prepared by {INSTITUTE_CONFIG.demoMode.preparedBy} for the institute management in Shahdol, MP.
            </p>

            <div className="space-y-3 text-xs text-[#667085] mb-6">
              <div className="p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80">
                <h4 className="font-bold text-[#151A3B] mb-1">1. Direct WhatsApp & Call Inquiries</h4>
                <p>Parents searching for maths coaching in Bhatnagar/Shahdol can instantly contact the institute with one tap, prefilling student grade and subject requirements.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80">
                <h4 className="font-bold text-[#151A3B] mb-1">2. Google Maps Landmark & Directions</h4>
                <p>Clear navigation to Doctor Kaushik ka Niwas Road near Jhula Pul Gayatri Mandir ensures new students never get lost finding the center.</p>
              </div>

              <div className="p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80">
                <h4 className="font-bold text-[#151A3B] mb-1">3. Fully Tailorable Content</h4>
                <p>All course names, batch schedules, fees, and faculty credentials can be updated to match current official offerings before public deployment.</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-3 border-t border-slate-100">
              <a
                href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  `Namaste, I am reviewing the demo website created for ${INSTITUTE_CONFIG.businessName}.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Test WhatsApp Handoff</span>
              </a>
              <button
                type="button"
                onClick={() => setShowPitchModal(false)}
                className="w-full sm:w-auto px-5 py-3 text-xs font-semibold text-[#151A3B] bg-[#F8F9FF] hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Close & Explore Demo
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
