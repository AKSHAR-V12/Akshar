import React, { useState } from 'react';
import { Menu, X, Phone, MessageSquare } from 'lucide-react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { DeltaLogo } from './DeltaLogo';

interface NavbarProps {
  onEnquireClick: () => void;
  activeSection?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onEnquireClick, activeSection = 'home' }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'Courses', href: '#learning', id: 'courses' },
    { label: 'Why Us', href: '#why-us', id: 'why-us' },
    { label: 'FAQs', href: '#faqs', id: 'faqs' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 border-b border-slate-100/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6 px-4 sm:px-6 lg:px-8 h-20">
        
        {/* Brand Lockup */}
        <a 
          href="#home" 
          onClick={(e) => {
            e.preventDefault();
            handleNavClick('#home');
          }}
          className="focus-visible:outline-2 focus-visible:outline-[#4F46E5] rounded-lg"
          aria-label="Delta Classes Home"
        >
          <DeltaLogo />
        </a>

        {/* Center Nav Links with active indicator */}
        <nav 
          aria-label="Main Navigation"
          className="hidden md:flex items-center gap-9 text-[13px] font-medium text-[#667085]"
        >
          {navLinks.map((link) => {
            const isActive = activeSection === link.id || (link.id === 'home' && (!activeSection || activeSection === 'home'));
            return (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className={`relative py-1 hover:text-[#151A3B] transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5] rounded ${
                  isActive ? 'text-[#151A3B] font-semibold' : ''
                }`}
              >
                <span>{link.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#4F46E5] rounded-full" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right Action: Pill Enquire Now Button */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onEnquireClick}
            className="px-6 py-2.5 text-xs font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] active:bg-[#312E81] rounded-full shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
          >
            Enquire Now
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            type="button"
            onClick={onEnquireClick}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#4338CA] rounded-full whitespace-nowrap"
          >
            Enquire
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#667085] hover:text-[#151A3B] rounded-lg focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
            aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Accessible Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white px-5 pt-3 pb-6 space-y-3 shadow-lg">
          <nav className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="px-3 py-2.5 rounded-xl text-sm font-medium text-[#151A3B] hover:bg-[#F8F9FF] hover:text-[#4F46E5] transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-slate-100 space-y-2">
            <a
              href={`tel:${INSTITUTE_CONFIG.phone}`}
              className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-full bg-[#F8F9FF] border border-slate-200/80 text-[#151A3B] text-xs font-semibold hover:bg-slate-100 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#4F46E5]" />
              <span>Call: {INSTITUTE_CONFIG.phoneDisplay}</span>
            </a>
            <a
              href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                INSTITUTE_CONFIG.whatsappMessageTemplate
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full px-4 py-2.5 rounded-full bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Message on WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
