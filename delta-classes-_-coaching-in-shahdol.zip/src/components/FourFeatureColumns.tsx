import React from 'react';
import { BookOpen, Target, TrendingUp, User } from 'lucide-react';

export const FourFeatureColumns: React.FC = () => {
  const features = [
    {
      id: 'expert-guidance',
      icon: <BookOpen className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Expert Guidance',
      description: 'Focused and structured learning support.',
    },
    {
      id: 'concept-clarity',
      icon: <Target className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Concept Clarity',
      description: 'Build strong fundamentals for long-term success.',
    },
    {
      id: 'regular-practice',
      icon: <TrendingUp className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Regular Practice',
      description: 'Improve accuracy and problem-solving skills.',
    },
    {
      id: 'personal-attention',
      icon: <User className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Personal Attention',
      description: 'Support at every step of your learning journey.',
    },
  ];

  return (
    <section aria-label="Core Institute Highlights" className="bg-white border-y border-slate-100 py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-0 lg:divide-x lg:divide-slate-100">
          {features.map((feat) => (
            <div key={feat.id} className="flex flex-col items-start lg:px-8 first:lg:pl-0 last:lg:pr-0">
              {/* Soft Lavender Icon Container */}
              <div className="w-12 h-12 rounded-2xl bg-[#EEF2FF] flex items-center justify-center mb-5 shrink-0">
                {feat.icon}
              </div>

              {/* Title */}
              <h3 className="text-base font-bold text-[#151A3B] mb-2 tracking-tight">
                {feat.title}
              </h3>

              {/* Description */}
              <p className="text-xs sm:text-[13px] text-[#667085] leading-relaxed">
                {feat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
