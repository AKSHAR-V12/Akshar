import React from 'react';
import { Lightbulb, BookOpen, MessageSquare, TrendingUp } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const benefits = [
    {
      id: 'conceptual-understanding',
      icon: <Lightbulb className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Conceptual Understanding',
      description: 'Go beyond memorization and truly understand.',
    },
    {
      id: 'structured-practice',
      icon: <BookOpen className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Structured Practice',
      description: 'Build consistency and confidence.',
    },
    {
      id: 'doubt-resolution',
      icon: <MessageSquare className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Doubt Resolution',
      description: 'Clear your doubts, move ahead faster.',
    },
    {
      id: 'consistent-progress',
      icon: <TrendingUp className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />,
      title: 'Consistent Progress',
      description: 'Small steps, steady growth, big results.',
    },
  ];

  return (
    <section id="why-us" aria-label="Why Choose Delta Classes" className="py-20 lg:py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Two-Column Split Layout matching reference image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          
          {/* Left Visual: Books on Desk with Blackboard Image (5 cols) */}
          <div className="lg:col-span-5 flex justify-center lg:justify-start">
            <div className="relative max-w-[420px] w-full">
              <div className="relative overflow-hidden rounded-3xl select-none">
                <img
                  src="/assets/books_composition.png"
                  alt="Textbooks and blackboard showing Small Steps Big Results"
                  className="w-full h-auto object-cover rounded-3xl"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Heading & 2x2 Grid of Benefits (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-[11px] font-bold tracking-[0.15em] text-[#4338CA] uppercase block">
              WHY CHOOSE DELTA CLASSES
            </span>

            <h2 
              className="text-3xl sm:text-4xl lg:text-[42px] font-normal text-[#151A3B] leading-[1.18]"
              style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
            >
              A Learning Approach<br className="hidden sm:inline" /> That Works
            </h2>

            {/* 2x2 Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-7 pt-4">
              {benefits.map((item) => (
                <div key={item.id} className="flex items-start gap-4">
                  {/* Circular Soft Lavender Icon Container */}
                  <div className="w-12 h-12 rounded-full bg-[#EEF2FF] flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>

                  <div>
                    <h3 className="text-sm sm:text-[15px] font-bold text-[#151A3B] mb-1">
                      {item.title}
                    </h3>
                    <p className="text-xs sm:text-[13px] text-[#667085] leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
