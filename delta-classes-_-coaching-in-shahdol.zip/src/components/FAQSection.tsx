import React, { useState } from 'react';
import { INSTITUTE_CONFIG, FAQItem } from '../config/instituteConfig';
import { ChevronDown, HelpCircle, Phone, MessageSquare } from 'lucide-react';

interface FAQSectionProps {
  onEnquireClick: () => void;
}

export const FAQSection: React.FC<FAQSectionProps> = ({ onEnquireClick }) => {
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({
    'faq-1': true,
  });

  const toggleItem = (id: string) => {
    setOpenItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <section id="faqs" aria-label="Frequently Asked Questions" className="py-20 bg-white border-b border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-[#4338CA] uppercase tracking-wider mb-2 font-semibold bg-[#EEF2FF] px-3 py-1 rounded-full">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Questions & Answers</span>
          </div>
          <h2 
            className="text-3xl sm:text-4xl font-normal text-[#151A3B] tracking-tight"
            style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
          >
            Frequently Asked Questions
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-[#667085] leading-relaxed">
            Transparent responses to common student and parent inquiries. For specifics on current batch capacity and admissions, please connect with the institute directly.
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3.5">
          {INSTITUTE_CONFIG.faqItems.map((item: FAQItem) => {
            const isOpen = !!openItems[item.id];
            return (
              <div 
                key={item.id}
                className="rounded-2xl border border-slate-100 bg-[#F8FAFF] transition-colors overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleItem(item.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-center justify-between p-5 sm:p-6 text-left text-sm sm:text-base font-bold text-[#151A3B] hover:text-[#4338CA] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#4F46E5]"
                >
                  <span className="pr-4">{item.question}</span>
                  <ChevronDown 
                    className={`w-5 h-5 text-[#4338CA] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`} 
                  />
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-[#667085] border-t border-slate-100/90 space-y-3 leading-relaxed">
                    <p>{item.answer}</p>
                    {item.actionHint && (
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={onEnquireClick}
                          className="inline-flex items-center gap-1.5 text-xs text-[#4338CA] hover:text-[#3730A3] underline underline-offset-4 cursor-pointer font-semibold"
                        >
                          <span>{item.actionHint}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Bottom Direct Help Callout */}
        <div className="mt-10 p-6 rounded-2xl bg-[#EEF2FF] border border-slate-200/60 flex flex-col sm:flex-row items-center justify-between gap-5 text-center sm:text-left">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-[#151A3B]">Have another question?</h3>
            <p className="text-xs text-[#667085] mt-0.5">Reach out directly via phone or WhatsApp for instant answers.</p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`tel:${INSTITUTE_CONFIG.phone}`}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-[#151A3B] bg-white hover:bg-slate-50 border border-slate-200/80 rounded-full transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#4338CA]" />
              <span>Call Institute</span>
            </a>
            <a
              href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                INSTITUTE_CONFIG.whatsappMessageTemplate
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white bg-[#4338CA] hover:bg-[#3730A3] rounded-full transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
