import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Phone, MessageSquare, Send } from 'lucide-react';

interface MobileStickyBarProps {
  onEnquireClick: () => void;
}

export const MobileStickyBar: React.FC<MobileStickyBarProps> = ({ onEnquireClick }) => {
  return (
    <aside aria-label="Mobile quick contact" className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 border-t border-slate-200/90 p-2 backdrop-blur-md shadow-lg">
      <div className="grid grid-cols-3 gap-2 max-w-md mx-auto">
        {/* Direct Call */}
        <a
          href={`tel:${INSTITUTE_CONFIG.phone}`}
          className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-[#F8F9FF] border border-slate-200/80 text-[#151A3B] text-xs font-semibold hover:bg-slate-100 transition-colors"
        >
          <Phone className="w-3.5 h-3.5 text-[#6546E8]" />
          <span className="truncate">Call</span>
        </a>

        {/* WhatsApp */}
        <a
          href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
            INSTITUTE_CONFIG.whatsappMessageTemplate
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span className="truncate">WhatsApp</span>
        </a>

        {/* Quick Enquire */}
        <button
          type="button"
          onClick={onEnquireClick}
          className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-[#6546E8] text-white text-xs font-bold hover:bg-[#4930C9] transition-colors cursor-pointer"
        >
          <Send className="w-3.5 h-3.5" />
          <span className="truncate">Enquire</span>
        </button>
      </div>
    </aside>
  );
};
