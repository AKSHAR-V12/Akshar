import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Phone, MessageSquare, MapPin, Instagram, Facebook } from 'lucide-react';
import { DeltaLogo } from './DeltaLogo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-100 text-[#667085] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 lg:py-16">
        
        {/* 4 Aligned Columns from Reference Image */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-8">
          
          {/* Column 1: Delta Classes Logo & Tagline (3 cols) */}
          <div className="md:col-span-3">
            <DeltaLogo />
          </div>

          {/* Column 2: Public Contact & Address (4 cols) */}
          <div className="md:col-span-4 space-y-3">
            <div className="flex items-center gap-2.5">
              <Phone className="w-3.5 h-3.5 text-[#151A3B] shrink-0" />
              <a 
                href={`tel:${INSTITUTE_CONFIG.phone}`} 
                className="hover:text-[#4338CA] font-medium text-[#151A3B] font-mono tabular-nums text-xs"
              >
                {INSTITUTE_CONFIG.phoneDisplay}
              </a>
            </div>

            <div className="flex items-center gap-2.5">
              <MessageSquare className="w-3.5 h-3.5 text-[#151A3B] shrink-0" />
              <a 
                href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  INSTITUTE_CONFIG.whatsappMessageTemplate
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#4338CA] font-medium text-[#151A3B] text-xs"
              >
                Chat on WhatsApp
              </a>
            </div>

            <div className="flex items-start gap-2.5 pt-1">
              <MapPin className="w-3.5 h-3.5 text-[#151A3B] shrink-0 mt-0.5" />
              <span className="text-[11px] text-[#667085] leading-relaxed">
                Doctor Koushik ka Niwas Road,<br />
                near Jhula Pul Gayatri Mandir,<br />
                Bhatnagar, Shahdol, Madhya Pradesh 484001
              </span>
            </div>
          </div>

          {/* Column 3: Navigation Links (2 cols) */}
          <div className="md:col-span-2 space-y-2.5">
            <div>
              <a href="#home" className="hover:text-[#4338CA] transition-colors font-medium">Home</a>
            </div>
            <div>
              <a href="#learning" className="hover:text-[#4338CA] transition-colors font-medium">Courses</a>
            </div>
            <div>
              <a href="#why-us" className="hover:text-[#4338CA] transition-colors font-medium">Why Us</a>
            </div>
            <div>
              <a href="#faqs" className="hover:text-[#4338CA] transition-colors font-medium">FAQs</a>
            </div>
            <div>
              <a href="#contact" className="hover:text-[#4338CA] transition-colors font-medium">Contact</a>
            </div>
          </div>

          {/* Column 4: Connect with us & Akshar credit (3 cols) */}
          <div className="md:col-span-3 space-y-4">
            <span className="text-xs font-bold text-[#151A3B] block">
              Connect with us
            </span>

            {/* Social Icons */}
            <div className="flex items-center gap-2.5">
              <a
                href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  INSTITUTE_CONFIG.whatsappMessageTemplate
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#F8F9FF] border border-slate-200/80 flex items-center justify-center text-[#151A3B] hover:text-[#4338CA] hover:border-[#4338CA]/30 transition-colors"
                aria-label="WhatsApp Contact"
              >
                <MessageSquare className="w-3.5 h-3.5" />
              </a>

              <a
                href="#contact"
                className="w-8 h-8 rounded-full bg-[#F8F9FF] border border-slate-200/80 flex items-center justify-center text-[#151A3B] hover:text-[#4338CA] hover:border-[#4338CA]/30 transition-colors"
                aria-label="Instagram Placeholder"
              >
                <Instagram className="w-3.5 h-3.5" />
              </a>

              <a
                href="#contact"
                className="w-8 h-8 rounded-full bg-[#F8F9FF] border border-slate-200/80 flex items-center justify-center text-[#151A3B] hover:text-[#4338CA] hover:border-[#4338CA]/30 transition-colors"
                aria-label="Facebook Placeholder"
              >
                <Facebook className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Discreet Concept Credit */}
            <div className="pt-2 flex items-center gap-1.5 text-[11px] text-[#667085]">
              <span className="w-3.5 h-3.5 rounded border border-slate-300 flex items-center justify-center text-[8px] font-mono">
                ⌘
              </span>
              <span>Website concept prepared by <strong className="text-[#151A3B] font-semibold">{INSTITUTE_CONFIG.demoMode.preparedBy}</strong></span>
            </div>
          </div>

        </div>

        {/* Bottom Bar matching reference */}
        <div className="mt-12 pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#667085]">
          <div>
            © 2025 Delta Classes. All rights reserved.
          </div>
          <div className="tracking-wider">
            Learn <span className="text-slate-300">·</span> Practice <span className="text-slate-300">·</span> Grow
          </div>
        </div>

      </div>
    </footer>
  );
};
