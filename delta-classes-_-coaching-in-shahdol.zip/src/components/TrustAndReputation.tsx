import React from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Star, ShieldCheck, HelpCircle, BookOpen, Award } from 'lucide-react';

export const TrustAndReputation: React.FC = () => {
  return (
    <section className="py-14 bg-[#F8F9FF] border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Public Listing Verification Strip */}
        <div className="p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#6546E8] uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Public Directory Record</span>
            </div>
            <div className="flex items-baseline gap-2.5">
              <div className="flex items-center text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <span className="text-xl font-bold text-[#151A3B] tabular-nums">5.0 / 5.0</span>
              <span className="text-sm text-[#667085]">(32 public directory reviews)</span>
            </div>
            <p className="text-xs text-[#667085] max-w-2xl leading-relaxed">
              {INSTITUTE_CONFIG.publicRatingNote}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 shrink-0 pt-2 md:pt-0">
            <div className="text-xs text-[#667085] md:border-l md:border-slate-200 md:pl-5">
              <span className="block font-semibold text-[#151A3B]">Local Math Education</span>
              <span>Bhatnagar, Shahdol (MP)</span>
            </div>
          </div>
        </div>

        {/* Responsible Educational Commitments */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-white border border-slate-200/70 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] mb-4">
              <BookOpen className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#151A3B] mb-2">No Generic Shortcuts</h3>
            <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
              Mathematics requires working through foundational derivations. We focus on ensuring students master core algebraic and geometric methods step-by-step.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200/70 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] mb-4">
              <HelpCircle className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#151A3B] mb-2">Zero Hesitation for Doubts</h3>
            <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
              Every math learner encounters roadblocks. A healthy classroom culture encourages asking questions immediately without fear of judgment.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200/70 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] mb-4">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#151A3B] mb-2">Honest Academic Guidance</h3>
            <p className="text-xs sm:text-sm text-[#667085] leading-relaxed">
              We never make unsupported claims or false percentage guarantees. Batch placement and guidance are tailored directly to each student's current baseline.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
