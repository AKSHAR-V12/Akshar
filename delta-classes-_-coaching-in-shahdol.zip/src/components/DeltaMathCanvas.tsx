import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Pause, Play, ChevronDown, ChevronUp, Compass } from 'lucide-react';

interface DeltaMathCanvasProps {
  className?: string;
}

export const DeltaMathCanvas: React.FC<DeltaMathCanvasProps> = ({ className = '' }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isRotating, setIsRotating] = useState(true);
  const [activePreset, setActivePreset] = useState<'perspective' | 'front' | 'top'>('perspective');
  const [activeGeometryMode, setActiveGeometryMode] = useState<'delta' | 'lattice' | 'full'>('full');
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);

  // References to communicate with render loop without re-triggering useEffect
  const stateRef = useRef({
    isRotating: true,
    targetCamPos: new THREE.Vector3(0, 2.0, 4.8),
    targetLookAt: new THREE.Vector3(0, 0.35, 0),
    currentLookAt: new THREE.Vector3(0, 0.35, 0),
    activeGeometryMode: 'full',
    isPointerDown: false,
    pointerStartX: 0,
    pointerStartY: 0,
    rotX: 0.12,
    rotY: 0.3,
    targetRotX: 0.12,
    targetRotY: 0.3,
  });

  useEffect(() => {
    stateRef.current.isRotating = isRotating;
  }, [isRotating]);

  useEffect(() => {
    stateRef.current.activeGeometryMode = activeGeometryMode;
  }, [activeGeometryMode]);

  useEffect(() => {
    if (activePreset === 'perspective') {
      stateRef.current.targetCamPos.set(0, 2.0, 4.8);
      stateRef.current.targetRotX = 0.12;
    } else if (activePreset === 'front') {
      stateRef.current.targetCamPos.set(0, 0.5, 4.9);
      stateRef.current.targetRotX = 0;
      stateRef.current.targetRotY = 0;
    } else if (activePreset === 'top') {
      stateRef.current.targetCamPos.set(0, 5.2, 0.2);
      stateRef.current.targetRotX = Math.PI / 2.2;
    }
  }, [activePreset]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL per Three.js directives
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 550;
    const height = container.clientHeight || 460;

    // Scene with soft horizon fog for minimalist light backdrop
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0xF8F9FF, 0.04);

    // Camera
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.copy(stateRef.current.targetCamPos);

    // Renderer (Alpha true to blend onto pure white / off-white container)
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // Procedural Studio Environment (RoomEnvironment) per skill guidelines
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Balanced Studio Rig for clean minimalist light background
    const keyLight = new THREE.DirectionalLight(0xFFFFFF, 2.0);
    keyLight.position.set(4, 7, 4);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.shadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0xF4F1FD, 0xEEF4FF, 1.4);
    scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight(0x6546E8, 1.2);
    rimLight.position.set(-4, 3, -3);
    scene.add(rimLight);

    // Soft Radial Contact Shadow Texture
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(128, 128, 10, 128, 128, 120);
      grad.addColorStop(0, 'rgba(21, 26, 59, 0.18)');
      grad.addColorStop(0.5, 'rgba(101, 70, 232, 0.06)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 256, 256);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    shadowTexture.colorSpace = THREE.SRGBColorSpace;

    const shadowPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(4.2, 4.2),
      new THREE.MeshBasicMaterial({
        map: shadowTexture,
        transparent: true,
        opacity: 0.8,
        depthWrite: false,
      })
    );
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -1.2;
    scene.add(shadowPlane);

    // Minimalist Compass Azimuth Plate on Floor
    const gridCanvas = document.createElement('canvas');
    gridCanvas.width = 512;
    gridCanvas.height = 512;
    const gCtx = gridCanvas.getContext('2d');
    if (gCtx) {
      gCtx.strokeStyle = 'rgba(101, 70, 232, 0.16)';
      gCtx.lineWidth = 1.5;
      gCtx.arc(256, 256, 240, 0, Math.PI * 2);
      gCtx.stroke();

      gCtx.beginPath();
      gCtx.strokeStyle = 'rgba(21, 26, 59, 0.08)';
      gCtx.arc(256, 256, 170, 0, Math.PI * 2);
      gCtx.arc(256, 256, 100, 0, Math.PI * 2);
      gCtx.stroke();

      // Degree tick marks
      for (let i = 0; i < 36; i++) {
        const rad = (i * Math.PI) / 18;
        const r1 = i % 3 === 0 ? 224 : 234;
        const r2 = 240;
        gCtx.beginPath();
        gCtx.moveTo(256 + Math.cos(rad) * r1, 256 + Math.sin(rad) * r1);
        gCtx.lineTo(256 + Math.cos(rad) * r2, 256 + Math.sin(rad) * r2);
        gCtx.stroke();
      }

      // Mathematical symbols
      gCtx.font = 'bold 18px "JetBrains Mono", sans-serif';
      gCtx.fillStyle = 'rgba(101, 70, 232, 0.4)';
      gCtx.textAlign = 'center';
      gCtx.textBaseline = 'middle';
      gCtx.fillText('Δ', 256, 35);
      gCtx.fillText('∑', 475, 256);
      gCtx.fillText('∫', 256, 475);
      gCtx.fillText('∞', 35, 256);
    }
    const gridTexture = new THREE.CanvasTexture(gridCanvas);
    gridTexture.colorSpace = THREE.SRGBColorSpace;
    gridTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    const compassPlate = new THREE.Mesh(
      new THREE.CircleGeometry(2.1, 64),
      new THREE.MeshStandardMaterial({
        map: gridTexture,
        transparent: true,
        opacity: 0.9,
        roughness: 0.2,
        metalness: 0.1,
        color: 0xFAFAFD,
      })
    );
    compassPlate.rotation.x = -Math.PI / 2;
    compassPlate.position.y = -1.18;
    scene.add(compassPlate);

    // ==========================================
    // PROCEDURAL 3-12 PART MATHEMATICAL MODEL
    // ==========================================
    const rootGroup = new THREE.Group();
    rootGroup.position.y = 0.08;
    scene.add(rootGroup);

    // Part 1: Main Extruded Delta (Δ) Symbol with Beveled Edges
    const deltaShape = new THREE.Shape();
    const side = 2.1;
    const h = (Math.sqrt(3) / 2) * side;
    deltaShape.moveTo(0, h * 0.55);
    deltaShape.lineTo(side / 2, -h * 0.45);
    deltaShape.lineTo(-side / 2, -h * 0.45);
    deltaShape.closePath();

    const innerHole = new THREE.Path();
    const innerScale = 0.52;
    innerHole.moveTo(0, h * 0.55 * innerScale + 0.05);
    innerHole.lineTo((-side / 2) * innerScale, -h * 0.45 * innerScale + 0.05);
    innerHole.lineTo((side / 2) * innerScale, -h * 0.45 * innerScale + 0.05);
    innerHole.closePath();
    deltaShape.holes.push(innerHole);

    const extrudeSettings = {
      depth: 0.26,
      bevelEnabled: true,
      bevelSegments: 5,
      steps: 1,
      bevelSize: 0.05,
      bevelThickness: 0.05,
    };

    const deltaGeo = new THREE.ExtrudeGeometry(deltaShape, extrudeSettings);
    deltaGeo.center();

    // Elegant Royal Purple PBR Material with subtle iridescent clearcoat
    const purplePbrMat = new THREE.MeshPhysicalMaterial({
      color: 0x6546E8,
      emissive: 0x1A1040,
      emissiveIntensity: 0.3,
      metalness: 0.65,
      roughness: 0.18,
      clearcoat: 0.9,
      clearcoatRoughness: 0.08,
    });

    const deltaMesh = new THREE.Mesh(deltaGeo, purplePbrMat);
    deltaMesh.castShadow = !isSoftwareGl;
    deltaMesh.receiveShadow = !isSoftwareGl;
    rootGroup.add(deltaMesh);

    // Part 2: Gyroscope Longitude Armillary Ring
    const ringGeo1 = new THREE.TorusGeometry(1.6, 0.025, 16, 96);
    const icyRingMat = new THREE.MeshPhysicalMaterial({
      color: 0x4930C9,
      metalness: 0.8,
      roughness: 0.25,
      transparent: true,
      opacity: 0.7,
    });
    const ringMesh1 = new THREE.Mesh(ringGeo1, icyRingMat);
    ringMesh1.rotation.y = Math.PI / 4;
    rootGroup.add(ringMesh1);

    // Part 3: Gyroscope Latitude Ring
    const ringGeo2 = new THREE.TorusGeometry(1.78, 0.02, 16, 96);
    const platinumRingMat = new THREE.MeshStandardMaterial({
      color: 0x6546E8,
      metalness: 0.7,
      roughness: 0.3,
      transparent: true,
      opacity: 0.6,
    });
    const ringMesh2 = new THREE.Mesh(ringGeo2, platinumRingMat);
    ringMesh2.rotation.x = Math.PI / 3;
    rootGroup.add(ringMesh2);

    // Part 4, 5, 6: Three Vertex Jewels (Concept, Practice, Mastery)
    const vertexNodeGeo = new THREE.OctahedronGeometry(0.11, 0);
    const vertexJewelMat = new THREE.MeshPhysicalMaterial({
      color: 0x4930C9,
      emissive: 0x6546E8,
      emissiveIntensity: 0.4,
      metalness: 0.3,
      roughness: 0.1,
      transmission: isSoftwareGl ? 0 : 0.7,
      opacity: isSoftwareGl ? 0.7 : 1,
      transparent: true,
    });

    const vertexTop = new THREE.Mesh(vertexNodeGeo, vertexJewelMat);
    vertexTop.position.set(0, h * 0.55 + 0.07, 0);
    rootGroup.add(vertexTop);

    const vertexRight = new THREE.Mesh(vertexNodeGeo, vertexJewelMat);
    vertexRight.position.set(side / 2 + 0.05, -h * 0.45 - 0.03, 0);
    rootGroup.add(vertexRight);

    const vertexLeft = new THREE.Mesh(vertexNodeGeo, vertexJewelMat);
    vertexLeft.position.set(-side / 2 - 0.05, -h * 0.45 - 0.03, 0);
    rootGroup.add(vertexLeft);

    // Part 7: Central Levitating Mathematical Polyhedron Core
    const coreGeo = new THREE.DodecahedronGeometry(0.26, 0);
    const coreMat = new THREE.MeshPhysicalMaterial({
      color: 0x4930C9,
      emissive: 0x6546E8,
      emissiveIntensity: 0.5,
      metalness: 0.4,
      roughness: 0.15,
      clearcoat: 1.0,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    coreMesh.position.set(0, -0.05, 0);
    rootGroup.add(coreMesh);

    // Part 8: Orbiting Mathematical Lattice Nodes
    const particleCount = 24;
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 2;
      const radius = 1.3 + Math.sin(i * 1.5) * 0.15;
      particlePositions[i * 3] = Math.cos(angle) * radius;
      particlePositions[i * 3 + 1] = Math.sin(angle * 2) * 0.22;
      particlePositions[i * 3 + 2] = Math.sin(angle) * radius;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x6546E8,
      size: 0.045,
      transparent: true,
      opacity: 0.75,
    });
    const particlePoints = new THREE.Points(particleGeo, particleMat);
    rootGroup.add(particlePoints);

    // Coordinate cross lines (Clean subtle slate)
    const axisMat = new THREE.LineBasicMaterial({
      color: 0xCBD5E1,
      transparent: true,
      opacity: 0.6,
    });
    const axisPoints = [
      new THREE.Vector3(-1.7, 0, 0),
      new THREE.Vector3(1.7, 0, 0),
      new THREE.Vector3(0, -1.1, 0),
      new THREE.Vector3(0, 1.7, 0),
    ];
    const axisGeo = new THREE.BufferGeometry().setFromPoints(axisPoints);
    const axisLines = new THREE.LineSegments(axisGeo, axisMat);
    rootGroup.add(axisLines);

    // Pointer Drag Interaction
    const onPointerDown = (e: PointerEvent) => {
      stateRef.current.isPointerDown = true;
      stateRef.current.pointerStartX = e.clientX;
      stateRef.current.pointerStartY = e.clientY;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!stateRef.current.isPointerDown) return;
      const dx = e.clientX - stateRef.current.pointerStartX;
      const dy = e.clientY - stateRef.current.pointerStartY;
      stateRef.current.pointerStartX = e.clientX;
      stateRef.current.pointerStartY = e.clientY;

      stateRef.current.targetRotY += dx * 0.007;
      stateRef.current.targetRotX += dy * 0.005;
      stateRef.current.targetRotX = Math.max(-0.6, Math.min(1.2, stateRef.current.targetRotX));
    };

    const onPointerUp = () => {
      stateRef.current.isPointerDown = false;
    };

    const domEl = renderer.domElement;
    domEl.style.cursor = 'grab';
    domEl.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 550;
      const h = container.clientHeight || 460;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Render Loop
    let animationFrameId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      const dt = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      if (stateRef.current.isRotating && !stateRef.current.isPointerDown) {
        stateRef.current.targetRotY += dt * 0.4;
      }

      const dampFactor = 1 - Math.exp(-8 * dt);
      stateRef.current.rotX += (stateRef.current.targetRotX - stateRef.current.rotX) * dampFactor;
      stateRef.current.rotY += (stateRef.current.targetRotY - stateRef.current.rotY) * dampFactor;

      rootGroup.rotation.x = stateRef.current.rotX;
      rootGroup.rotation.y = stateRef.current.rotY;

      ringMesh1.rotation.z = elapsed * 0.25;
      ringMesh2.rotation.y = -elapsed * 0.2;
      coreMesh.rotation.y = elapsed * 0.7;
      coreMesh.rotation.x = elapsed * 0.4;
      coreMesh.position.y = Math.sin(elapsed * 2) * 0.03;
      particlePoints.rotation.y = elapsed * 0.12;

      const jewelScale = 1 + Math.sin(elapsed * 2.5) * 0.06;
      vertexTop.scale.set(jewelScale, jewelScale, jewelScale);
      vertexRight.scale.set(jewelScale, jewelScale, jewelScale);
      vertexLeft.scale.set(jewelScale, jewelScale, jewelScale);

      camera.position.lerp(stateRef.current.targetCamPos, dampFactor * 0.8);
      stateRef.current.currentLookAt.lerp(stateRef.current.targetLookAt, dampFactor * 0.8);
      camera.lookAt(stateRef.current.currentLookAt);

      const mode = stateRef.current.activeGeometryMode;
      deltaMesh.visible = mode === 'delta' || mode === 'full';
      ringMesh1.visible = mode === 'lattice' || mode === 'full';
      ringMesh2.visible = mode === 'lattice' || mode === 'full';
      axisLines.visible = mode === 'lattice' || mode === 'full';
      particlePoints.visible = mode === 'full';

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      domEl.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);

      deltaGeo.dispose();
      purplePbrMat.dispose();
      ringGeo1.dispose();
      ringGeo2.dispose();
      icyRingMat.dispose();
      platinumRingMat.dispose();
      vertexNodeGeo.dispose();
      vertexJewelMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      axisGeo.dispose();
      axisMat.dispose();
      shadowPlane.geometry.dispose();
      (shadowPlane.material as THREE.Material).dispose();
      shadowTexture.dispose();
      compassPlate.geometry.dispose();
      (compassPlate.material as THREE.Material).dispose();
      gridTexture.dispose();

      renderer.dispose();
      if (container.contains(domEl)) {
        container.removeChild(domEl);
      }
    };
  }, []);

  return (
    <div className={`relative w-full h-full min-h-[420px] select-none ${className}`}>
      {/* 3D Canvas Mount */}
      <div 
        ref={mountRef} 
        className="w-full h-full absolute inset-0 rounded-2xl overflow-hidden focus:outline-none"
        aria-label="Interactive 3D Delta Mathematical Geometry Model"
        role="region"
      />

      {/* Top Spec Badge */}
      <div className="absolute top-4 left-4 z-10 pointer-events-none">
        <div className="flex items-center gap-2 text-xs font-mono text-[#6546E8] font-semibold tracking-wider">
          <Compass className="w-3.5 h-3.5 text-[#6546E8]" />
          <span>GEOMETRIC MODEL</span>
          <span className="text-slate-300">·</span>
          <span className="text-slate-500 font-normal">Δ = b² - 4ac</span>
        </div>
        <p className="text-[11px] text-[#667085] mt-0.5 font-sans">Interactive 3D mathematical core</p>
      </div>

      {/* Viewport-First Collapsible Bottom Control Dock */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 w-[92%] max-w-[420px]">
        {/* Toggle Collapse Pill */}
        <div className="flex justify-center -mb-2">
          <button
            type="button"
            onClick={() => setIsDockCollapsed(!isDockCollapsed)}
            className="flex items-center gap-1 px-2.5 py-0.5 text-[11px] font-medium text-[#667085] bg-white border border-slate-200/90 rounded-t-md hover:text-[#151A3B] transition-colors cursor-pointer shadow-sm"
            aria-label={isDockCollapsed ? "Expand 3D Controls" : "Collapse 3D Controls"}
          >
            {isDockCollapsed ? (
              <>
                <ChevronUp className="w-3 h-3 text-[#6546E8]" />
                <span>3D Controls</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3 h-3 text-[#667085]" />
                <span>Hide Controls</span>
              </>
            )}
          </button>
        </div>

        {/* Minimalist Light Dock Surface */}
        {!isDockCollapsed && (
          <div className="bg-white/95 border border-slate-200/80 rounded-xl p-2 shadow-lg flex items-center justify-between gap-2 text-xs text-[#151A3B]">
            {/* Play / Pause Rotation */}
            <button
              type="button"
              onClick={() => setIsRotating(!isRotating)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#F8F9FF] hover:bg-[#ECE8FD] text-[#151A3B] font-medium transition-colors cursor-pointer whitespace-nowrap"
              title={isRotating ? "Pause Auto-rotation" : "Resume Auto-rotation"}
            >
              {isRotating ? <Pause className="w-3.5 h-3.5 text-[#6546E8]" /> : <Play className="w-3.5 h-3.5 text-[#6546E8]" />}
              <span className="text-[11px]">{isRotating ? 'Pause' : 'Rotate'}</span>
            </button>

            {/* View Presets */}
            <div className="flex items-center gap-1 bg-[#F8F9FF] p-0.5 rounded-lg border border-slate-100">
              <button
                type="button"
                onClick={() => setActivePreset('perspective')}
                className={`px-2 py-1 text-[11px] rounded transition-colors cursor-pointer whitespace-nowrap ${
                  activePreset === 'perspective' ? 'bg-[#6546E8] text-white font-medium shadow-xs' : 'text-[#667085] hover:text-[#151A3B]'
                }`}
              >
                Angle
              </button>
              <button
                type="button"
                onClick={() => setActivePreset('front')}
                className={`px-2 py-1 text-[11px] rounded transition-colors cursor-pointer whitespace-nowrap ${
                  activePreset === 'front' ? 'bg-[#6546E8] text-white font-medium shadow-xs' : 'text-[#667085] hover:text-[#151A3B]'
                }`}
              >
                Front
              </button>
              <button
                type="button"
                onClick={() => setActivePreset('top')}
                className={`px-2 py-1 text-[11px] rounded transition-colors cursor-pointer whitespace-nowrap ${
                  activePreset === 'top' ? 'bg-[#6546E8] text-white font-medium shadow-xs' : 'text-[#667085] hover:text-[#151A3B]'
                }`}
              >
                Plan
              </button>
            </div>

            {/* Geometry Display Toggle */}
            <div className="flex items-center gap-1 bg-[#F8F9FF] p-0.5 rounded-lg border border-slate-100">
              <button
                type="button"
                onClick={() => setActiveGeometryMode('delta')}
                className={`px-2 py-1 text-[11px] rounded transition-colors cursor-pointer whitespace-nowrap ${
                  activeGeometryMode === 'delta' ? 'bg-[#ECE8FD] text-[#6546E8] font-semibold' : 'text-[#667085] hover:text-[#151A3B]'
                }`}
                title="Delta Emblem Focus"
              >
                Δ Core
              </button>
              <button
                type="button"
                onClick={() => setActiveGeometryMode('full')}
                className={`px-2 py-1 text-[11px] rounded transition-colors cursor-pointer whitespace-nowrap ${
                  activeGeometryMode === 'full' ? 'bg-[#ECE8FD] text-[#6546E8] font-semibold' : 'text-[#667085] hover:text-[#151A3B]'
                }`}
                title="Full Mathematical Rig"
              >
                Full Rig
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
