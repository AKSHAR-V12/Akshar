import React from 'react';
import { Target, GraduationCap, ArrowRight } from 'lucide-react';

interface LearningProgramsProps {
  onSelectProgram: (programTitle: string) => void;
  onEnquireClick: () => void;
}

export const LearningPrograms: React.FC<LearningProgramsProps> = ({ 
  onSelectProgram, 
  onEnquireClick 
}) => {
  const courses = [
    {
      id: 'maths-coaching',
      title: 'Mathematics Coaching',
      description: 'Strengthen your basics, solve with confidence and improve problem-solving skills.',
      icon: (
        <span className="font-mono text-base font-bold text-[#4338CA]">
          √x
        </span>
      ),
    },
    {
      id: 'concept-practice',
      title: 'Concept Building and Practice',
      description: 'Focus on fundamentals with regular practice and analysis.',
      icon: (
        <Target className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />
      ),
    },
    {
      id: 'academic-support',
      title: 'Academic Support / Exam Preparation',
      description: 'Guidance and practice for better performance in your exams.',
      icon: (
        <GraduationCap className="w-5 h-5 text-[#4338CA]" strokeWidth={1.8} />
      ),
    },
  ];

  return (
    <section id="learning" aria-label="Learning Programs" className="py-20 lg:py-24 bg-[#F8FAFF] border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Layout: Left intro (4 cols) + Right 3 cards (8 cols) matching reference image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          
          {/* Left Intro Column (4 cols) */}
          <div className="lg:col-span-4 space-y-4 lg:pr-2">
            <span className="text-[11px] font-bold tracking-[0.15em] text-[#4338CA] uppercase block">
              OUR LEARNING PROGRAMS
            </span>

            <h2 
              className="text-3xl sm:text-4xl font-normal text-[#151A3B] leading-[1.18]"
              style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}
            >
              Courses Designed for Better Tomorrow
            </h2>

            <p className="text-xs sm:text-[13px] text-[#667085] leading-relaxed">
              We focus on building strong concepts, regular practice and consistent improvement — helping students achieve their academic goals with confidence.
            </p>

            <p className="text-[11px] text-[#667085] italic pt-1">
              * These are proposed courses for demo purposes. Please contact the institute for current offerings.
            </p>

            <div className="pt-2">
              <button
                type="button"
                onClick={onEnquireClick}
                className="inline-flex items-center justify-center px-6 py-3 text-xs sm:text-[13px] font-semibold text-[#4338CA] hover:text-[#3730A3] bg-white hover:bg-slate-50 border border-[#4338CA]/30 rounded-full transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-[#4F46E5] shadow-2xs"
              >
                Enquire About Courses
              </button>
            </div>
          </div>

          {/* Right 3 Cards (8 cols) */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-3 gap-5">
            {courses.map((course) => (
              <div 
                key={course.id}
                className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-100 shadow-[0_4px_20px_-4px_rgba(21,26,59,0.04)] flex flex-col justify-between hover:shadow-[0_8px_30px_-6px_rgba(79,70,229,0.12)] transition-all duration-200"
              >
                <div>
                  {/* Square icon container with soft lavender background */}
                  <div className="w-11 h-11 rounded-xl bg-[#EEF2FF] flex items-center justify-center mb-6 shrink-0">
                    {course.icon}
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-[#151A3B] mb-3 leading-snug">
                    {course.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-[13px] text-[#667085] leading-relaxed mb-6">
                    {course.description}
                  </p>
                </div>

                {/* Link */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onSelectProgram(course.title)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4338CA] hover:text-[#3730A3] transition-colors cursor-pointer group"
                  >
                    <span>Ask About This Program</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
