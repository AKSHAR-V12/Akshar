import React, { useState, useEffect } from 'react';
import { INSTITUTE_CONFIG } from '../config/instituteConfig';
import { Send, Phone, MessageSquare, CheckCircle2, AlertCircle, Sparkles, User, BookOpen } from 'lucide-react';

interface EnquirySectionProps {
  selectedProgram?: string;
  onClearSelectedProgram?: () => void;
}

export const EnquirySection: React.FC<EnquirySectionProps> = ({ 
  selectedProgram = '', 
  onClearSelectedProgram 
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    gradeLevel: 'Class 10',
    program: selectedProgram || 'Mathematics Coaching',
    preferredCallback: 'Anytime during day',
    queryNotes: '',
    consent: true,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedWhatsAppUrl, setSubmittedWhatsAppUrl] = useState('');

  useEffect(() => {
    if (selectedProgram) {
      setFormData((prev) => ({ ...prev, program: selectedProgram }));
    }
  }, [selectedProgram]);

  const classOptions = [
    'Class 9',
    'Class 10',
    'Class 11 (Maths)',
    'Class 12 (Maths)',
    'Competitive Baseline / Foundation',
    'Other / Not sure',
  ];

  const callbackOptions = [
    'Anytime during day',
    'Morning (9:00 AM – 12:00 PM)',
    'Afternoon (1:00 PM – 4:00 PM)',
    'Evening (4:00 PM – 8:00 PM)',
  ];

  const programOptions = [
    'Mathematics Coaching',
    'Concept Building and Practice',
    'Academic Support / Exam Preparation',
    'General Enquiry / Batch Timings',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.fullName.trim()) {
      errs.fullName = 'Please enter student or parent name';
    } else if (formData.fullName.trim().length < 2) {
      errs.fullName = 'Name should be at least 2 characters';
    }

    const cleanPhone = formData.phone.replace(/[^0-9]/g, '');
    if (!cleanPhone) {
      errs.phone = 'Please enter a 10-digit mobile number';
    } else if (cleanPhone.length < 10) {
      errs.phone = 'Please enter a valid 10-digit mobile number';
    }

    if (!formData.consent) {
      errs.consent = 'Please confirm consent to be contacted regarding this enquiry';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const waText = [
      `Namaste Delta Classes,`,
      `I would like to enquire about coaching for ${formData.fullName}.`,
      `• Class/Level: ${formData.gradeLevel}`,
      `• Program: ${formData.program}`,
      `• Contact Phone: ${formData.phone}`,
      formData.preferredCallback ? `• Preferred Callback Time: ${formData.preferredCallback}` : '',
      formData.queryNotes.trim() ? `• Question / Note: ${formData.queryNotes.trim()}` : '',
      `Please share available batches, timings, and admission details.`,
    ]
      .filter(Boolean)
      .join('\n');

    const cleanInstitutePhone = INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '');
    const waUrl = `https://wa.me/${cleanInstitutePhone}?text=${encodeURIComponent(waText)}`;
    
    setSubmittedWhatsAppUrl(waUrl);
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFormData({
      fullName: '',
      phone: '',
      gradeLevel: 'Class 10',
      program: 'Mathematics Coaching',
      preferredCallback: 'Anytime during day',
      queryNotes: '',
      consent: true,
    });
    setErrors({});
    if (onClearSelectedProgram) onClearSelectedProgram();
  };

  return (
    <section 
      id="contact" 
      aria-label="Student and Parent Enquiry" 
      className="py-20 bg-white border-b border-slate-100 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Call & WhatsApp Info (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-2 text-xs font-mono text-[#6546E8] uppercase tracking-wider font-semibold">
              <Sparkles className="w-4 h-4" />
              <span>Admissions & Inquiries</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-normal text-[#151A3B] tracking-tight" style={{ fontFamily: 'var(--font-serif)', textWrap: 'balance' }}>
              Connect Directly with Delta Classes
            </h2>

            <p className="text-sm text-[#667085] leading-relaxed">
              Have questions regarding class batches, mathematics curriculum, or trial sessions? Submit your details or reach out through publicly listed channels.
            </p>

            {/* Direct Instant Action Cards */}
            <div className="space-y-3 pt-2">
              <a
                href={`tel:${INSTITUTE_CONFIG.phone}`}
                className="flex items-center gap-4 p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80 hover:border-[#6546E8]/40 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-[#ECE8FD] flex items-center justify-center text-[#6546E8] group-hover:bg-[#6546E8] group-hover:text-white transition-colors shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-mono text-[#667085] block uppercase tracking-wider">Direct Call</span>
                  <span className="text-sm font-bold text-[#151A3B] font-mono tabular-nums">{INSTITUTE_CONFIG.phoneDisplay}</span>
                  <span className="text-[11px] text-[#667085] block">Tap to call institute directly</span>
                </div>
              </a>

              <a
                href={`https://wa.me/${INSTITUTE_CONFIG.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                  INSTITUTE_CONFIG.whatsappMessageTemplate
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80 hover:border-emerald-500/40 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors shrink-0">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-mono text-emerald-700 block uppercase tracking-wider">Instant WhatsApp</span>
                  <span className="text-sm font-bold text-[#151A3B]">Chat on WhatsApp</span>
                  <span className="text-[11px] text-[#667085] block">Prefilled enquiry message ready to send</span>
                </div>
              </a>
            </div>

            {/* Local Institute Contact Note */}
            <div className="p-4 rounded-xl bg-[#F8F9FF] border border-slate-200/80 text-xs text-[#667085] space-y-2">
              <div className="font-semibold text-[#151A3B]">Public Contact Information:</div>
              <p>• Listed Contact: <span className="text-[#151A3B] font-mono font-medium">{INSTITUTE_CONFIG.phoneDisplay}</span></p>
              <p>• Location: Doctor Kaushik ka Niwas Road, near Jhula Pul Gayatri Mandir, Bhatnagar, Shahdol, MP 484001</p>
              <p className="text-[11px] text-[#667085] pt-1">
                Note: This contact number is taken from public research. Inquirers can verify current session availability directly.
              </p>
            </div>

          </div>

          {/* Right Column: High-Conversion Lead Form (7 cols) */}
          <div className="lg:col-span-7 bg-[#F8F9FF] border border-slate-200/80 rounded-2xl p-7 sm:p-9 shadow-xs relative">
            
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                
                <div>
                  <h3 className="text-xl font-bold text-[#151A3B] mb-1">
                    Student / Parent Enquiry Form
                  </h3>
                  <p className="text-xs text-[#667085]">
                    Fill in your details below. You can also send this enquiry via WhatsApp.
                  </p>
                </div>

                {/* Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="fullName" className="block text-xs font-semibold text-[#151A3B] mb-1">
                      Student / Parent Name <span className="text-[#6546E8]">*</span>
                    </label>
                    <input
                      id="fullName"
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Rahul Sharma"
                      className={`w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-white border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
                        errors.fullName ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-[#6546E8] focus:ring-[#ECE8FD]'
                      }`}
                    />
                    {errors.fullName && (
                      <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.fullName}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-xs font-semibold text-[#151A3B] mb-1">
                      Mobile Number <span className="text-[#6546E8]">*</span>
                    </label>
                    <input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="10-digit mobile number"
                      className={`w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-white border rounded-xl focus:outline-none focus:ring-2 transition-colors ${
                        errors.phone ? 'border-rose-400 focus:ring-rose-200' : 'border-slate-200 focus:border-[#6546E8] focus:ring-[#ECE8FD]'
                      }`}
                    />
                    {errors.phone && (
                      <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.phone}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Grade & Program Selection */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="gradeLevel" className="block text-xs font-semibold text-[#151A3B] mb-1">
                      Class / Level Interested In
                    </label>
                    <select
                      id="gradeLevel"
                      value={formData.gradeLevel}
                      onChange={(e) => setFormData({ ...formData, gradeLevel: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#6546E8]"
                    >
                      {classOptions.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="program" className="block text-xs font-semibold text-[#151A3B] mb-1">
                      Program / Subject
                    </label>
                    <select
                      id="program"
                      value={formData.program}
                      onChange={(e) => setFormData({ ...formData, program: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#6546E8]"
                    >
                      {programOptions.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Preferred Callback Time */}
                <div>
                  <label htmlFor="preferredCallback" className="block text-xs font-semibold text-[#151A3B] mb-1">
                    Preferred Callback Window <span className="text-[#667085] font-normal">(Optional)</span>
                  </label>
                  <select
                    id="preferredCallback"
                    value={formData.preferredCallback}
                    onChange={(e) => setFormData({ ...formData, preferredCallback: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs text-[#151A3B] bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#6546E8]"
                  >
                    {callbackOptions.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Additional Question */}
                <div>
                  <label htmlFor="queryNotes" className="block text-xs font-semibold text-[#151A3B] mb-1">
                    Specific Question or Student Details <span className="text-[#667085] font-normal">(Optional)</span>
                  </label>
                  <textarea
                    id="queryNotes"
                    rows={2}
                    value={formData.queryNotes}
                    onChange={(e) => setFormData({ ...formData, queryNotes: e.target.value })}
                    placeholder="e.g. Inquiring about Class 10 board prep batches and timings..."
                    className="w-full px-3.5 py-2 text-xs text-[#151A3B] bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-[#6546E8]"
                  />
                </div>

                {/* Consent Checkbox */}
                <div>
                  <label className="flex items-start gap-2.5 text-xs text-[#667085] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.consent}
                      onChange={(e) => setFormData({ ...formData, consent: e.target.checked })}
                      className="mt-0.5 rounded border-slate-300 text-[#6546E8] focus:ring-[#6546E8]"
                    />
                    <span>
                      I consent to receive contact from Delta Classes regarding this coaching enquiry.
                    </span>
                  </label>
                  {errors.consent && (
                    <p className="text-[11px] text-rose-500 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.consent}</span>
                    </p>
                  )}
                </div>

                {/* Submit Action Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-[#6546E8] hover:bg-[#4930C9] active:bg-[#3D25A8] rounded-xl transition-colors shadow-xs cursor-pointer focus-visible:outline-2 focus-visible:outline-[#6546E8]"
                  >
                    <Send className="w-4 h-4" />
                    <span>Submit Enquiry & Open WhatsApp Handoff</span>
                  </button>
                  <p className="text-center text-[11px] text-[#667085] mt-2">
                    Transparent Demo Mode: You will have the option to review or instantly open WhatsApp.
                  </p>
                </div>

              </form>
            ) : (
              /* Success & Transparent Demo Handoff State */
              <div className="py-6 px-2 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>

                <div>
                  <h3 className="text-xl font-bold text-[#151A3B]">
                    Enquiry Validated Successfully!
                  </h3>
                  <p className="text-xs text-[#667085] mt-1 max-w-md mx-auto">
                    Thank you, <strong className="text-[#6546E8] font-bold">{formData.fullName}</strong>.
                  </p>
                </div>

                {/* Transparent Notice */}
                <div className="p-4 rounded-xl bg-white border border-slate-200 text-xs text-[#667085] text-left space-y-2">
                  <div className="flex items-center gap-1.5 text-[#6546E8] font-semibold">
                    <Sparkles className="w-4 h-4" />
                    <span>Demo Mode Confirmation</span>
                  </div>
                  <p>
                    Because this is an interactive sales demo without a remote production database, this submission has not been stored on any remote server.
                  </p>
                  <p>
                    To send this enquiry directly to Delta Classes right now, tap the button below to open WhatsApp with all your details pre-formatted!
                  </p>
                </div>

                {/* WhatsApp Action */}
                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <a
                    href={submittedWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Continue on WhatsApp Now</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-4 py-3 text-xs font-semibold text-[#151A3B] bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors cursor-pointer"
                  >
                    Submit Another Query
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
