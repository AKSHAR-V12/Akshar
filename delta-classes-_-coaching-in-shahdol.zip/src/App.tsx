/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DemoBanner } from './components/DemoBanner';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FourFeatureColumns } from './components/FourFeatureColumns';
import { LearningPrograms } from './components/LearningPrograms';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ContactBand } from './components/ContactBand';
import { LocationAndDirections } from './components/LocationAndDirections';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { MobileStickyBar } from './components/MobileStickyBar';
import { EnquiryModal } from './components/EnquiryModal';

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState<string>('');

  const openEnquiry = (programTitle?: string) => {
    if (programTitle) {
      setSelectedProgram(programTitle);
    }
    setIsModalOpen(true);
  };

  const closeEnquiry = () => {
    setIsModalOpen(false);
    setSelectedProgram('');
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#151A3B] flex flex-col antialiased selection:bg-[#EEF2FF] selection:text-[#4338CA] pb-16 md:pb-0">
      {/* Sales Pitch Demo Banner */}
      <DemoBanner />

      {/* Slim Navbar matching Reference */}
      <Navbar onEnquireClick={() => openEnquiry()} />

      <main className="flex-1">
        {/* A. Hero Section */}
        <Hero 
          onEnquireClick={() => openEnquiry()} 
          onExploreClick={() => scrollToSection('learning')} 
        />

        {/* B. Four Feature Columns */}
        <FourFeatureColumns />

        {/* C. Learning Programs (3 Cards) */}
        <LearningPrograms 
          onSelectProgram={(title) => openEnquiry(title)}
          onEnquireClick={() => openEnquiry()}
        />

        {/* D. Why Choose Delta Classes (Books Visual & 2x2 Benefits Grid) */}
        <WhyChooseUs />

        {/* E. Contact Conversion Band (Paper Plane & WhatsApp / Call CTAs) */}
        <ContactBand onEnquireClick={() => openEnquiry()} />

        {/* F. Campus Location & Google Maps Navigation */}
        <LocationAndDirections />

        {/* G. Frequently Asked Questions (Accordion) */}
        <FAQSection onEnquireClick={() => openEnquiry()} />
      </main>

      {/* H. Footer matching Reference */}
      <Footer />

      {/* Mobile Sticky Quick Contact Action Bar (Capped <= 15% Mobile Viewport) */}
      <MobileStickyBar onEnquireClick={() => openEnquiry()} />

      {/* Interactive Enquiry Modal */}
      <EnquiryModal 
        isOpen={isModalOpen}
        onClose={closeEnquiry}
        selectedProgram={selectedProgram}
      />
    </div>
  );
}
