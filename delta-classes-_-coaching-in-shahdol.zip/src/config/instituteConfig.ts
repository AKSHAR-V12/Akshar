/**
 * DELTA CLASSES - Central Institute Configuration
 * 
 * All business details, public research markers, and proposed demo content
 * are centralized here so the institute owner or webmaster can edit them
 * in one single location.
 * 
 * IMPORTANT:
 * - Fields with unverified status are explicitly marked so the owner knows
 *   what details to verify before final public launch.
 * - publicRating & reviewCount are removable/toggleable.
 */

export interface CourseProgram {
  id: string;
  title: string;
  tagline: string;
  description: string;
  focusTopics: string[];
  recommendedFor: string;
  mathSymbol: string;
  isProposedCategory: boolean;
}

export interface LearningFeature {
  id: string;
  title: string;
  shortDescription: string;
  detailedPoints: string[];
  iconName: 'Compass' | 'Layers' | 'HelpCircle' | 'TrendingUp';
  isProposedBenefit: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  actionHint?: string;
}

export interface InstituteConfig {
  businessName: string;
  shortTagline: string;
  category: string;
  locationCity: string;
  locationState: string;
  pincode: string;
  addressFull: string;
  landmark: string;
  phone: string;
  phoneDisplay: string;
  whatsappMessageTemplate: string;
  mapSearchQuery: string;
  googleMapsDirectionsUrl: string;
  
  // Public directory indicators (verified at time of research; toggleable)
  showPublicRating: boolean;
  publicRating: number | null;
  reviewCount: number | null;
  publicRatingNote: string;
  
  // Institute status placeholders (unverified as noted in brief)
  operatingHours: string | null;
  faculty: null;
  results: null;
  
  // Demo Mode parameters for Sales Pitch by Akshar
  demoMode: {
    enabled: boolean;
    preparedBy: string;
    presentationTarget: string;
    pitchHeadline: string;
    disclaimer: string;
  };

  courses: CourseProgram[];
  learningFeatures: LearningFeature[];
  faqItems: FAQItem[];
}

export const INSTITUTE_CONFIG: InstituteConfig = {
  businessName: 'DELTA CLASSES',
  shortTagline: 'Focused Mathematics & Academic Concept Coaching',
  category: 'Maths / Math Tutoring & Education Center',
  locationCity: 'Shahdol',
  locationState: 'Madhya Pradesh',
  pincode: '484001',
  addressFull: 'Doctor Kaushik ka Niwas Road, near Jhula Pul Gayatri Mandir, Bhatnagar, Shahdol, Madhya Pradesh 484001',
  landmark: 'Near Jhula Pul & Gayatri Mandir, Bhatnagar',
  phone: '+919407813744',
  phoneDisplay: '+91 94078 13744',
  whatsappMessageTemplate: 'Namaste Delta Classes, I would like to enquire about your coaching programs in Shahdol. Please share the available classes, subjects, timings, and admission details.',
  mapSearchQuery: 'DELTA CLASSES near Jhula Pul Gayatri Mandir, Bhatnagar, Shahdol, Madhya Pradesh 484001',
  googleMapsDirectionsUrl: 'https://www.google.com/maps/search/?api=1&query=DELTA+CLASSES+near+Jhula+Pul+Gayatri+Mandir%2C+Bhatnagar%2C+Shahdol%2C+Madhya+Pradesh+484001',
  
  // Public listing data noted during research
  showPublicRating: true,
  publicRating: 5.0,
  reviewCount: 32,
  publicRatingNote: 'Public listing rating: 5.0/5 · 32 reviews (as found during research; verify before launch).',
  
  // Unverified fields intentionally kept as placeholders or null per specification
  operatingHours: null, // "Please contact the institute for current batch timings"
  faculty: null,        // No unverified faculty names depicted
  results: null,        // No fabricated ranks or percentages
  
  // Demo presentation meta
  demoMode: {
    enabled: true,
    preparedBy: 'Akshar',
    presentationTarget: 'Delta Classes Owner / Management (Shahdol)',
    pitchHeadline: 'Proposed Digital Identity & Student Enquiry Portal for Delta Classes',
    disclaimer: 'This is a private concept proposal designed by Akshar to demonstrate the value of a high-conversion web presence for Delta Classes. Not an officially approved release.',
  },

  // Proposed Course Categories (Editable by owner)
  courses: [
    {
      id: 'maths-coaching',
      title: 'Mathematics Coaching',
      tagline: 'Deep problem-solving & rigorous conceptual clarity',
      description: 'Systematic coverage of core mathematical principles, algebraic structures, geometry, and calculus designed to eliminate math anxiety.',
      focusTopics: [
        'Fundamental Theorems & Step-by-Step Logic',
        'Speed & Accuracy in Numerical Calculations',
        'Analytical Thinking & Formula Retention',
        'Board & Foundation Level Problems'
      ],
      recommendedFor: 'Secondary & Senior Secondary Students',
      mathSymbol: '∑ Δ f(x)',
      isProposedCategory: true,
    },
    {
      id: 'concept-practice',
      title: 'Concept Building and Practice',
      tagline: 'Bridging textbook definitions to everyday problem-solving',
      description: 'Special emphasis on structured practice modules where students solve graded problem sets with guided mentor feedback.',
      focusTopics: [
        'Graded Problem Sheets (Basics to Advanced)',
        'Error Analysis & Common Misconceptions',
        'Daily Practice Assignments',
        'Formula Notebook & Short Revision Techniques'
      ],
      recommendedFor: 'Students seeking strong foundational base',
      mathSymbol: '∫ [x² + C] dx',
      isProposedCategory: true,
    },
    {
      id: 'academic-support',
      title: 'Academic Support & Exam Preparation',
      tagline: 'Targeted preparation for school tests, boards & competitive baseline',
      description: 'Comprehensive test series, previous years question analysis, and time-management strategies under simulated exam conditions.',
      focusTopics: [
        'Chapter-wise Periodic Evaluations',
        'Time Management & Answer Presentation',
        'One-on-One Doubt Resolution Sessions',
        'Pre-Exam Revision Drills'
      ],
      recommendedFor: 'Exam-bound students preparing for boards & tests',
      mathSymbol: 'lim_{x→∞} P(x)',
      isProposedCategory: true,
    },
  ],

  // Proposed Educational Approach (4 Minimal Feature Blocks)
  learningFeatures: [
    {
      id: 'expert-guidance',
      title: 'Expert Guidance',
      shortDescription: 'Structured mentorship focused on clearing misconceptions and breaking down complex mathematics step by step.',
      detailedPoints: [
        'Methodical explanations tailored to each student’s current foundation',
        'Systematic coverage of algebraic, trigonometric, and geometric logic',
        'Emphasis on analytical problem solving over rote memorization'
      ],
      iconName: 'Compass',
      isProposedBenefit: true,
    },
    {
      id: 'concept-clarity',
      title: 'Concept Clarity',
      shortDescription: 'Core mathematical principles are taught from first principles so formulas are understood naturally.',
      detailedPoints: [
        'Clear derivation and geometric intuition before numerical drills',
        'Bridging textbook theories to real-world applications and diagrams',
        'Eliminating fear of abstract mathematical notations'
      ],
      iconName: 'Layers',
      isProposedBenefit: true,
    },
    {
      id: 'regular-practice',
      title: 'Regular Practice',
      shortDescription: 'Carefully graded daily and weekly problem sheets designed to build calculation speed and accuracy.',
      detailedPoints: [
        'Calibrated problem progression from foundational to advanced',
        'Consistent arithmetic and formula retention exercises',
        'Timed mock problem sets to build test-taking endurance'
      ],
      iconName: 'TrendingUp',
      isProposedBenefit: true,
    },
    {
      id: 'personal-attention',
      title: 'Personal Attention',
      shortDescription: 'A supportive, patient environment where every doubt is addressed without hesitation or rush.',
      detailedPoints: [
        'One-on-one question clarification sessions after every module',
        'Detailed diagnostic review of common student calculation traps',
        'Constructive feedback to foster genuine academic self-reliance'
      ],
      iconName: 'HelpCircle',
      isProposedBenefit: true,
    },
  ],

  // Frequently Asked Questions
  faqItems: [
    {
      id: 'faq-1',
      question: 'Which classes and subjects are available at Delta Classes?',
      answer: 'Delta Classes is primarily known as a mathematics coaching and tutoring center. For exact details regarding current batch grades (e.g., Classes 9th, 10th, 11th, 12th) and any supplementary subjects, please submit an enquiry or call directly so the institute can confirm current offerings.',
      actionHint: 'Click "Enquire Now" or call +91 94078 13744 to confirm current class offerings.',
    },
    {
      id: 'faq-2',
      question: 'What are the current batch timings?',
      answer: 'Batch schedules vary by class level, school timing, and academic term. To obtain the latest morning or evening batch slots, please call or WhatsApp the institute directly.',
      actionHint: 'Direct WhatsApp link is available below to check batch slots.',
    },
    {
      id: 'faq-3',
      question: 'How can I enquire about the fee structure?',
      answer: 'Fee details depend on the selected program, class level, and batch type. Delta Classes provides transparent fee information directly to students and parents during consultation. Contact the institute for verified details.',
    },
    {
      id: 'faq-4',
      question: 'Where is the institute located and how can I visit?',
      answer: 'Delta Classes is located on Doctor Kaushik ka Niwas Road, near Jhula Pul and Gayatri Mandir in Bhatnagar, Shahdol, Madhya Pradesh (Pincode: 484001). You can use the Google Maps link on this page for turn-by-turn directions.',
      actionHint: 'View the Location & Directions section for landmark guidance.',
    },
    {
      id: 'faq-5',
      question: 'How do admissions and trial/demo sessions work?',
      answer: 'Interested parents and students can call +91 94078 13744 or fill out the enquiry form above. The institute will guide you through batch availability, registration steps, and trial class options.',
    },
  ],
};
